package com.instademo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class instalogin {
	@GetMapping("/LOGIN")
	public String login()
	{
		return "Successfully Login";
	}

}
