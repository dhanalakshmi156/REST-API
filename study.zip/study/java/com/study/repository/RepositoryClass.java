package com.study.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.study.demo.study;

public interface RepositoryClass extends JpaRepository<study,Integer> {

}
