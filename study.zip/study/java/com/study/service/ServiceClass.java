package com.study.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.study.demo.study;
import com.study.repository.RepositoryClass;

@Service
public class ServiceClass {

	RepositoryClass Rclass;
	public List<study> read() {
		
		return  Rclass.findAll();
	}

}
